package com.amsvy.assignment4.beans;

public class Publisher {
	private String publisherid;
	private String name;
	private String address;
	public String getPublisherid() {
		return publisherid;
	}
	public void setPublisherid(String publisherid) {
		this.publisherid = publisherid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
}
